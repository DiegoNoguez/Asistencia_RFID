const usuariosSimulados = [
  {
    id_usuario: 1,
    matricula: "1",
    password: "1",
    rol: "alumno",
    nombre: "ANGEL EDUARDO",
    ape1: "ANGELES",
    ape2: "MIRANDA",
    correo: "angel@ejemplo.com",
    grupo: "3401",
    materias: [
      "ACF-0905",
      "SCC-1017",
      "SCD-1027",
      "AEF-1031",
      "SCA-1026",
      "SCD-1003",
      "ACA-0907",
      "INGLES"
    ]
  },
  {
    matricula: "2",
    password: "2",
    rol: "profesor",
    nombre: "Rodolfo",
    ape1: "Alcantara",
    ape2: "Rosales",
    correo: "rodolfo@ejemplo.com",
    materias: [
      {
        clave: "ACF-0905",
        nombre: "Ecuaciones Diferenciales"
      }
    ]
  },
  {
    matricula: "3",
    password: "3",
    rol: "admin",
    nombre: "Administrador",
    ape1: "",
    ape2: "",
    correo: "admin@tesji.edu.mx"
  }
];
